```python
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
plt.style.use("fivethirtyeight")
%matplotlib inline

# For reading stock data from yahoo
from pandas_datareader.data import DataReader
import yfinance as yf
from pandas_datareader import data as pdr

yf.pdr_override()

# For time stamps
from datetime import datetime


# The tech stocks we'll use for this analysis
tech_list = ['AAPL', 'GOOG', 'MSFT', 'AMZN']

# Set up End and Start times for data grab
tech_list = ['AAPL', 'GOOG', 'MSFT', 'AMZN']

end = datetime.now()
start = datetime(end.year - 1, end.month, end.day)

for stock in tech_list:
    globals()[stock] = yf.download(stock, start, end)
    

company_list = [AAPL, GOOG, MSFT, AMZN]
company_name = ["APPLE", "GOOGLE", "MICROSOFT", "AMAZON"]

for company, com_name in zip(company_list, company_name):
    company["company_name"] = com_name
    
df = pd.concat(company_list, axis=0)
df.tail(10)

```


```python
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
```


```python
sns.set_style('whitegrid')
plt.style.use("fivethirtyeight")
%matplotlib inline
```


```python
# For reading stock data from yahoo
from pandas_datareader.data import DataReader
import yfinance as yf
from pandas_datareader import data as pdr
```


```python
yf.pdr_override()
```


```python
# For time stamps
from datetime import datetime
```


```python
# The tech stocks we'll use for this analysis
tech_list = ['AAPL', 'GOOG', 'MSFT', 'AMZN']

# Set up End and Start times for data grab
tech_list = ['AAPL', 'GOOG', 'MSFT', 'AMZN']

end = datetime.now()
start = datetime(end.year - 1, end.month, end.day)
```


```python
dt_now = pd.Timestamp.utcnow()
```


```python
for stock in tech_list:
    globals()[stock] = yf.download(stock, start, end)
```

    [*********************100%***********************]  1 of 1 completed
    [*********************100%***********************]  1 of 1 completed
    [*********************100%***********************]  1 of 1 completed
    [*********************100%***********************]  1 of 1 completed
    
    1 Failed download:
    - AMZN: No data found for this date range, symbol may be delisted
    


```python
company_list = [AAPL, GOOG, MSFT, AMZN]
company_name = ["APPLE", "GOOGLE", "MICROSOFT", "AMAZON"]
```


```python
for company, com_name in zip(company_list, company_name):
    company["company_name"] = com_name
```


```python
df = pd.concat(company_list, axis=0)
df.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
      <th>company_name</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2023-05-19</th>
      <td>316.739990</td>
      <td>318.750000</td>
      <td>316.369995</td>
      <td>318.339996</td>
      <td>318.339996</td>
      <td>27529500.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-22</th>
      <td>318.600006</td>
      <td>322.589996</td>
      <td>318.010010</td>
      <td>321.179993</td>
      <td>321.179993</td>
      <td>24115700.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-23</th>
      <td>320.029999</td>
      <td>322.720001</td>
      <td>315.250000</td>
      <td>315.260010</td>
      <td>315.260010</td>
      <td>30797200.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-24</th>
      <td>314.730011</td>
      <td>316.500000</td>
      <td>312.609985</td>
      <td>313.850006</td>
      <td>313.850006</td>
      <td>23384900.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-25</th>
      <td>323.239990</td>
      <td>326.899994</td>
      <td>320.000000</td>
      <td>325.920013</td>
      <td>325.920013</td>
      <td>43301700.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-26</th>
      <td>324.019989</td>
      <td>333.399994</td>
      <td>323.880005</td>
      <td>332.890015</td>
      <td>332.890015</td>
      <td>36630600.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-30</th>
      <td>335.230011</td>
      <td>335.739990</td>
      <td>330.519989</td>
      <td>331.209991</td>
      <td>331.209991</td>
      <td>29503100.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-05-31</th>
      <td>332.290009</td>
      <td>335.940002</td>
      <td>327.329987</td>
      <td>328.390015</td>
      <td>328.390015</td>
      <td>45950600.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-06-01</th>
      <td>325.929993</td>
      <td>333.529999</td>
      <td>324.720001</td>
      <td>332.579987</td>
      <td>332.579987</td>
      <td>26773900.0</td>
      <td>MICROSOFT</td>
    </tr>
    <tr>
      <th>2023-06-02</th>
      <td>334.250000</td>
      <td>337.500000</td>
      <td>332.549988</td>
      <td>335.399994</td>
      <td>335.399994</td>
      <td>25864000.0</td>
      <td>MICROSOFT</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Summary Stats
AAPL.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>250.000000</td>
      <td>250.000000</td>
      <td>250.000000</td>
      <td>250.000000</td>
      <td>250.000000</td>
      <td>2.500000e+02</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>151.665441</td>
      <td>153.564600</td>
      <td>150.055080</td>
      <td>151.925920</td>
      <td>151.436716</td>
      <td>7.388613e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>12.637145</td>
      <td>12.414989</td>
      <td>12.912570</td>
      <td>12.735195</td>
      <td>12.808340</td>
      <td>2.239948e+07</td>
    </tr>
    <tr>
      <th>min</th>
      <td>126.010002</td>
      <td>127.769997</td>
      <td>124.169998</td>
      <td>125.019997</td>
      <td>124.656975</td>
      <td>3.519590e+07</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>142.699997</td>
      <td>144.592503</td>
      <td>140.917496</td>
      <td>142.912502</td>
      <td>142.261520</td>
      <td>5.784518e+07</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>150.180000</td>
      <td>152.330002</td>
      <td>148.485001</td>
      <td>150.795006</td>
      <td>150.332176</td>
      <td>7.018920e+07</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>161.235004</td>
      <td>162.814995</td>
      <td>160.015003</td>
      <td>161.899998</td>
      <td>161.320263</td>
      <td>8.336160e+07</td>
    </tr>
    <tr>
      <th>max</th>
      <td>181.029999</td>
      <td>181.779999</td>
      <td>179.259995</td>
      <td>180.949997</td>
      <td>180.949997</td>
      <td>1.647624e+08</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(15, 10))
plt.subplots_adjust(top=1.25, bottom=1.2)

for i, company in enumerate(company_list, 1):
    plt.subplot(2, 2, i)
    company['Adj Close'].plot()
    plt.ylabel('Adj Close')
    plt.xlabel(None)
    plt.title(f"Closing Price of {tech_list[i - 1]}")
    
plt.tight_layout()
```


    
![png](output_13_0.png)
    



```python
AAPL['Daily Return'].plot(ax=axes[0,0], legend=True, linestyle='--', marker='o')
axes[0,0].set_title('APPLE')
```




    Text(0.5, 1.0, 'APPLE')




```python
# Calculate daily returns
AAPL['Daily Return'] = AAPL['Adj Close'].pct_change()

# Calculate daily average return
#daily_avg_return = AAPL['Daily Return'].mean()

# Plot daily average return
plt.figure(figsize=(10, 6))
plt.plot(AAPL.index, AAPL['Daily Return'], label='Daily Return')
#plt.axhline(daily_avg_return, color='r', linestyle='--', label='Daily Avg Return')
plt.xlabel('Date')
plt.ylabel('Return')
plt.title('Daily Return of AAPL')
plt.legend(loc="upper left")
plt.show()

```


    
![png](output_15_0.png)
    



```python
GOOG['Daily return'] = GOOG['Adj Close'].pct_change()
plt.figure(figsize=(10,4))
plt.plot(GOOG.index,GOOG['Daily Return'], label='Daily Return')
plt.xlabel('Date')
plt.ylabel('Return')
plt.title('Daily Return of GOOG')
plt.legend(loc="upper left")
plt.show()
```


    
![png](output_16_0.png)
    



```python
# Define the company names and their corresponding data
companies = ['AAPL', 'GOOG', 'MSFT']
data = [AAPL['Adj Close'][-1], GOOG['Adj Close'][-1], MSFT['Adj Close'][-1]]

# Create the pie chart
plt.figure(figsize=(6, 6))
plt.pie(data, labels=companies, autopct='%.1f%%')
plt.title('Market Cap Distribution')
plt.axis('equal')  # Ensure the pie chart is circular
plt.show()

```


    
![png](output_17_0.png)
    



```python

```
